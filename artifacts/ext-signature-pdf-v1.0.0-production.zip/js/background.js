(function(){chrome.action.onClicked.addListener((()=>{chrome.runtime.openOptionsPage()}))})();
//# sourceMappingURL=background.js.map